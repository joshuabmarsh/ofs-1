---
title: Can The Basic Attention Token (BAT) Save Us?
date: "2021-03-21T22:12:03.284Z"
description: "Cryptocurrencies like BAT are relevant now more than ever. As of writing this post the price of a single Bitcoin has just surpassed $60k USD as many suggest its anti-inflationary supply limit (mining rewards reduce over time, known as halving events), decentralisation and mobility that it is a much better store of value than gold. Making Bitcoin Gold 2.0."
---

WIP WIP

Porting from WP on rootdomain.
